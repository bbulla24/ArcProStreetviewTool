﻿using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Navigation;

namespace StreetView_ArcPro
{
    /// <summary>
    /// Interaction logic for DockpaneView.xaml
    /// </summary>

    public partial class DockpaneView : UserControl
    {
        string url = null;

        public DockpaneView()
        {
            InitializeComponent();
            _this = this;
        }

        //****Use this so you can gain access to the DockpaneView from the MapTool code
        private static DockpaneView _this = null;

        // static method to get reference to my DockpaneView instance
        static public DockpaneView MyDockpaneView => _this;


        public static implicit operator DockpaneView(DockPane v)
        {
            throw new NotImplementedException();
        }

        private void btnStreetViewDock_Click(object sender, RoutedEventArgs e)
        {
            var cmdID = FrameworkApplication.GetPlugInWrapper(@"StreetView_ArcPro_StreetView_Tool") as ICommand;
            cmdID.Execute(null);
        }

        public Uri currentUri;
        private void streetViewControl_Navigating(object sender, NavigatingCancelEventArgs e)
        {
            //MessageBox.Show("NAVIGATING" + e.Uri.ToString());
        }

        private void streetViewControl_Navigated(object sender, NavigationEventArgs e)
        {
            //MessageBox.Show("NAVIGATING" + e.Uri.ToString());
        }

        private void streetViewControl_LoadCompleted(object sender, NavigationEventArgs e)
        {
            if (chkLink.IsChecked == true)
            {
                int pos1 = streetViewControl.Source.ToString().IndexOf("viewpoint=");
                string bothCoords = streetViewControl.Source.ToString().Substring(pos1 + ("viewport=".Length) + 1);
                var split = bothCoords.Split(',');
                var split2 = split[1].Split('&');

                txtX.Text = split[0].ToString();
                txtY.Text = split2[0].ToString();


                MapPoint cameraPoint = MapPointBuilder.CreateMapPoint(Convert.ToDouble(split[0]), Convert.ToDouble(split2[0]), SpatialReferences.WGS84);
                var projectedPoint = GeometryEngine.Instance.Project(cameraPoint, DockpaneViewModel._camera.SpatialReference) as MapPoint;

                //if (MapView.Active != null)
                //    DockpaneViewModel._camera = MapView.Active.Camera;

                //MessageBox.Show(streetViewControl.Source.ToString());

                //ArcGIS.Desktop.Framework.Dialogs.MessageBox.Show(streetViewControl.Source.ToString() + Environment.NewLine + split[0].ToString() + " - " + split[1].ToString());
            }


        }

        private void chkBrowser_Checked(object sender, RoutedEventArgs e)
        {
            Properties.Settings.Default.svBrowserSetting = true;
        }

        private void chkBrowser_Unchecked(object sender, RoutedEventArgs e)
        {
            Properties.Settings.Default.svBrowserSetting = false;
        }


        private static System.IDisposable _overlayObject = null;

        public MapViewOverlayControl crossHairOverlay;

        private void chkLink_Checked(object sender, RoutedEventArgs e)
        {
            //draw a cross-hair in centre of active map

            if (MapView.Active == null) return;

            var mapView = MapView.Active;
            var crossHairControl = new CrossHairUserControl();

            //use the active mapview to get the size of the mapview display
            var xRatio = 0.0;
            var yRatio = 0.0;
            var viewSize = mapView.GetViewSize();

            if (viewSize.Width != 0.0 && viewSize.Height != 0.0)
            {
                var xPosition = viewSize.Width / 2;
                var yPosition = viewSize.Height / 2;
                // now offset for 1/2 of the user control's size
                xPosition -= 16;
                yPosition -= 16;
                xRatio = xPosition / viewSize.Width;
                yRatio = yPosition / viewSize.Height;
            }

            // Create a MapViewOverlayControl using the user control
            crossHairOverlay = new MapViewOverlayControl(
                    crossHairControl, true, false,
                    false, OverlayControlRelativePosition.Center, xRatio, yRatio);

            //Add to the active map view
            mapView.AddOverlayControl(crossHairOverlay);
        }


        private void chkLink_Unchecked(object sender, RoutedEventArgs e)
        {
            var mapView = MapView.Active;
            mapView.RemoveOverlayControl(crossHairOverlay);
        }

        //private void btnURL_Click(object sender, RoutedEventArgs e)
        //{
        //    txtURL.Text = streetViewControl.Source.ToString();
        //}
    }
}
