﻿using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Mapping.Events;
using System;
using System.Windows.Input;

namespace StreetView_ArcPro
{
    internal class DockpaneViewModel : DockPane
    {
        private const string _dockPaneID = "StreetView_ArcPro_Dockpane";

        protected DockpaneViewModel()
        {
            MapViewCameraChangedEvent.Subscribe(OnCameraChanged);
            ActiveMapViewChangedEvent.Subscribe(OnActiveMapViewChanged);

            _panToCmd = new RelayCommand(() => MapView.Active.PanToAsync(Camera), () => { return MapView.Active != null; });

            if (MapView.Active != null)
                Camera = MapView.Active.Camera;
        }

        ~DockpaneViewModel()
        {
            ActiveMapViewChangedEvent.Unsubscribe(OnActiveMapViewChanged);
            MapViewCameraChangedEvent.Unsubscribe(OnCameraChanged);

            _panToCmd.Disconnect();
        }





        /// <summary>
        /// Show the DockPane.
        /// </summary>
        internal static void Show()
        {
            DockPane pane = FrameworkApplication.DockPaneManager.Find(_dockPaneID);
            if (pane == null)
                return;

            pane.Activate();
        }

        /// <summary>
        /// Text shown near the top of the DockPane.
        /// </summary>
        private string _heading = "My DockPane";
        public string Heading
        {
            get { return _heading; }
            set
            {
                SetProperty(ref _heading, value, () => Heading);
            }
        }


        static public Camera _camera;

        public Camera Camera
        {
            get { return _camera; }
            set
            {
                SetProperty(ref _camera, value, () => Camera);
            }
        }

        private RelayCommand _panToCmd;
        public ICommand PanToCmd
        {
            get { return _panToCmd; }
        }


        private void OnCameraChanged(MapViewCameraChangedEventArgs obj)
        {
            if (obj.MapView == MapView.Active)
                Camera = obj.CurrentCamera;

            //Access the web control through the View
            DockpaneView myView = DockpaneView.MyDockpaneView;
            double theHeading = 0;

            if (myView.chkLink.IsChecked == true)
            {
                //variable for the coordinate of the mouse click - in WGS84
                MapPoint cameraPoint = MapPointBuilder.CreateMapPoint(Camera.X, Camera.Y, Camera.SpatialReference);
                var projectedPoint = GeometryEngine.Instance.Project(cameraPoint, SpatialReferences.WGS84) as MapPoint;

                //MessageBox.Show($@"projected [x,y]: {projectedPoint.X}, {projectedPoint.Y}");

                if (Camera.Heading < 0)
                    theHeading = Math.Abs(Camera.Heading);
                else
                    theHeading = 360 - Camera.Heading;

                //MessageBox.Show(theHeading.ToString());

                myView.currentUri = new Uri(@"https://www.google.com/maps/@?api=1&map_action=pano&viewpoint=" + projectedPoint.Y + "," + projectedPoint.X + "&Heading=" + theHeading);
                myView.streetViewControl.Navigate(@"https://www.google.com/maps/@?api=1&map_action=pano&viewpoint=" + projectedPoint.Y + "," + projectedPoint.X + "&Heading=" + theHeading);
            }
        }

        private void OnActiveMapViewChanged(ActiveMapViewChangedEventArgs obj)
        {
            if (obj.IncomingView == null)
            {
                Camera = null;
                return;
            }

            Camera = obj.IncomingView.Camera;
        }
    }

    /// <summary>
    /// Button implementation to show the DockPane.
    /// </summary>
    internal class Dockpane_ShowButton : Button
    {
        protected override void OnClick()
        {
            DockpaneViewModel.Show();
        }
    }
}
