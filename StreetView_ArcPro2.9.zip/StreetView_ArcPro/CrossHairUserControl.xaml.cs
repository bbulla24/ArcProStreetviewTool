﻿using System.Windows.Controls;

namespace StreetView_ArcPro
{
    /// <summary>
    /// Interaction logic for CrossHairUserControl.xaml
    /// </summary>
    public partial class CrossHairUserControl : UserControl
    {
        public CrossHairUserControl()
        {
            InitializeComponent();
        }
    }
}
