﻿using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using System;
using System.Threading.Tasks;

namespace StreetView_ArcPro
{
    internal class ApplicationSettingsViewModel : Page
    {
        //This sets up the StreetView Setting variable
        private bool _origSvBrowserSetting;
        private bool _svBrowserSetting;
        public bool svBrowserSetting
        {
            get { return _svBrowserSetting; }
            set
            {
                if (SetProperty(ref _svBrowserSetting, value, () => svBrowserSetting))
                    base.IsModified = true;
            }
        }

        /// <summary>
        /// Invoked when the OK or apply button on the property sheet has been clicked.
        /// </summary>
        /// <returns>A task that represents the work queued to execute in the ThreadPool.</returns>
        /// <remarks>This function is only called if the page has set its IsModified flag to true.</remarks>
        protected override Task CommitAsync()
        {
            if (IsDirty())
            {
                //save the new settings
                StreetView_ArcPro.Properties.Settings settings = StreetView_ArcPro.Properties.Settings.Default;

                settings.svBrowserSetting = svBrowserSetting;

                settings.Save();
            }

            return Task.FromResult(0);
        }

        /// <summary>
        /// Called when the page loads because to has become visible.
        /// </summary>
        /// <returns>A task that represents the work queued to execute in the ThreadPool.</returns>
        protected override Task InitializeAsync()
        {
            //get the default settings
            StreetView_ArcPro.Properties.Settings settings = StreetView_ArcPro.Properties.Settings.Default;

            //assign to the values binding to the controls
            _svBrowserSetting = settings.svBrowserSetting;
            //keep track of the original values (used for comparison when saving)
            _origSvBrowserSetting = svBrowserSetting;

            return Task.FromResult(0);
        }


        private bool IsDirty()
        {
            if (_origSvBrowserSetting != svBrowserSetting)
            {
                return true;
            }

            return false;
        }


        /// <summary>
        /// Called when the page is destroyed.
        /// </summary>
        protected override void Uninitialize()
        {
        }

        /// <summary>
        /// Text shown inside the page hosted by the property sheet
        /// </summary>
        public string DataUIContent
        {
            get
            {
                return base.Data[0] as string;
            }
            set
            {
                SetProperty(ref base.Data[0], value, () => DataUIContent);
            }
        }
    }

    /// <summary>
    /// Button implementation to show the property sheet.
    /// </summary>
    internal class ApplicationSettings_ShowButton : Button
    {
        protected override void OnClick()
        {
            // collect data to be passed to the page(s) of the property sheet
            Object[] data = new object[] { "Page UI content" };

            if (!PropertySheet.IsVisible)
                PropertySheet.ShowDialog("StreetView_ArcPro_ApplicationSettings", "StreetView_ArcPro_ApplicationSettings", data);

        }
    }
}
