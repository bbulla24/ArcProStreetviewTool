﻿using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using System;
using System.Threading.Tasks;

namespace StreetView_ArcPro
{
    internal class StreetView_Tool : MapTool
    {
        public StreetView_Tool()
        {
            IsSketchTool = true;
            SketchType = SketchGeometryType.Point;
            SketchOutputMode = SketchOutputMode.Map;
        }

        protected override Task OnToolActivateAsync(bool active)
        {
            return base.OnToolActivateAsync(active);
        }

        protected override Task<bool> OnSketchCompleteAsync(Geometry geometry)
        {
            double lat;     //variables to hold the Lat and Long values
            double lng;

            //variable for the coordinate of the mouse click - in WGS84
            var coord = GeometryEngine.Instance.Project(geometry, SpatialReferences.WGS84) as MapPoint;

            //get the lat/lng of a valid click and then call the SetMapLocation of the DockpaneView to update the WebBrowser
            if (coord != null)
            {
                lng = coord.X;
                lat = coord.Y;

                if (Properties.Settings.Default.svBrowserSetting == true)
                {
                    //*****Use this code if you want to open the separate web browser
                    var streetViewLink = @"https://www.google.com/maps/@?api=1&map_action=pano&viewpoint=" + lat + "," + lng;
                    var psi = new System.Diagnostics.ProcessStartInfo
                    {
                        UseShellExecute = true,
                        FileName = streetViewLink
                    };

                    System.Diagnostics.Process.Start(psi);        //opens the webbrowser  
                }
                else
                {
                    //Open the dockpane if it isn't already open
                    DockPane pane = FrameworkApplication.DockPaneManager.Find("StreetView_ArcPro_Dockpane");
                    pane.Activate();

                    //Access the web control through the View
                    DockpaneView myView = DockpaneView.MyDockpaneView;
                    myView.currentUri = new Uri(@"https://www.google.com/maps/@?api=1&map_action=pano&viewpoint=" + lat + "," + lng + "&Heading=");
                    myView.streetViewControl.Navigate(@"https://www.google.com/maps/@?api=1&map_action=pano&viewpoint=" + lat + "," + lng + "&Heading=");

                    //myView.webViewControl.Source = new Uri(@"https://www.google.com/maps/@?api=1&map_action=pano&viewpoint=" + lat + "," + lng  + "&Heading=");

                }

            }

            var ret = QueuedTask.Run(() =>
            {
                return true;
            }
            );

            return ret;
        }
    }
}
